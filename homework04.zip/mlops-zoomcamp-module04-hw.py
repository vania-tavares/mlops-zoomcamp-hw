#!/usr/bin/env python
# coding: utf-8


import pickle
import pandas as pd
import numpy as np
import sys


with open('model.bin', 'rb') as f_in:
    dv, lr = pickle.load(f_in)


categorical = ['PUlocationID', 'DOlocationID']

def read_data(filename):
    df = pd.read_parquet(filename)
    
    df['duration'] = df.dropOff_datetime - df.pickup_datetime
    df['duration'] = df.duration.dt.total_seconds() / 60

    df = df[(df.duration >= 1) & (df.duration <= 60)].copy()

    df[categorical] = df[categorical].fillna(-1).astype('int').astype('str')
    
    return df


def run():
	year = sys.argv[1]
	month = sys.argv[2]
	df = read_data('https://nyc-tlc.s3.amazonaws.com/trip+data/fhv_tripdata_'+str(year)+'-'+str(month)+'.parquet')

	dicts = df[categorical].to_dict(orient='records')
	X_val = dv.transform(dicts)
	y_pred = lr.predict(X_val)

	# What's the mean predicted duration for this dataset?

	print(f'mean predicted duration for this dataset is: {np.mean(y_pred)}')

	df['ride_id'] = f'{str(year)}/{str(month)}_' + df.index.astype('str')
	df['y_pred']=y_pred

	df_result = df[['ride_id','y_pred']]

	output_file = 'resultsFile'
	
	df_result.to_parquet(
	    output_file,
	    engine='pyarrow',
	    compression=None,
	    index=False
	)

if __name__ == '__main__':
	run()






